from setuptools import find_packages, setup

setup(
    name='gcputil',
    version='0.1',
    packages=['gcp_cloud_util'],
    description='Test',
    author='Ezzat Demnati',
    author_email='ezzatdemnati@gmail.com',
    license='MIT',
    zip_safe=False,
    install_requires=[
        #'google-cloud-storage==1.19.0',
        #'google-cloud-pubsub== 0.41.0',
        #'google-cloud-firestore==1.4.0',
        #'pandas==0.25.1',
        #'python-dateutil== 2.8.0',
    ] 
                            
)